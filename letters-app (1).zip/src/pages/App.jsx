import React from 'react';

export default function App() {
  return (
    <div className='bg-white text-black dark:bg-black dark:text-white min-h-screen'>
      <h1 className='text-3xl font-bold p-4'>Letters: Web Novel & Webtoon Platform</h1>
      <p className='p-4'>기본 UI 구성 완료. 번역 버튼, 업로드 기능 추가 예정!</p>
    </div>
  );
}